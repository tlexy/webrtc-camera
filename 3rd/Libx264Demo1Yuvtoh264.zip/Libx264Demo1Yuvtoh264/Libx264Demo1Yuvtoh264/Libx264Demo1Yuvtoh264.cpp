// Libx264Demo1Yuvtoh264.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

// error1: You must include stdint.h or inttypes.h before x264.h
// error2: error LNK2019: �޷��������ⲿ���� _x264_param_default���÷����ں��� _main �б�����

//platform:X86_64,,���Ǳ����libx264��64λ�ġ�

#include <stdint.h>
///#include <inttypes.h>
#include <iostream>
 
extern "C"
{
#include "x264.h"
#include "x264_config.h"
}
 
int width = 352;
int height = 288;
int csp = X264_CSP_I420;//yuv420p


int main(void)
{
	x264_param_t mParam;
	x264_param_default(&mParam);
	std::cout << "hello world" << std::endl;
	system("pause");
	


	
	int ret;
	int y_size;
	int i, j;

	FILE* fp_src = fopen("./ande10_yuv420p_352x288.yuv", "rb");
	FILE* fp_dst = fopen("output_yuv420p_352x288_4slice.h264", "wb");

	//Encode frame number
	//if set 0, encode all frame
	int frame_num = 0;

	int iNal = 0;
	x264_nal_t* pNals = NULL;
	x264_t* pHandle = NULL;
	x264_picture_t* pPic_in = (x264_picture_t*)malloc(sizeof(x264_picture_t));
	x264_picture_t* pPic_out = (x264_picture_t*)malloc(sizeof(x264_picture_t));
	x264_param_t* pParam = (x264_param_t*)malloc(sizeof(x264_param_t));

	//Check
	if (fp_src == NULL || fp_dst == NULL) {
		printf("Error open files.\n");
		return -1;
	}

	x264_param_default(pParam);   //�������ṹ�帳Ĭ��ֵ
	//����preset��tune
	x264_param_default_preset(pParam, "fast", "zerolatency");  

															   //�޸Ĳ��ֲ���
	pParam->i_csp = csp;
	pParam->i_width = width;   // ����
	pParam->i_height = height;  // �߶�
	pParam->i_fps_num = 25;     // ����֡�ʣ����ӣ�
	pParam->i_fps_den = 1;      // ����֡��ʱ��1s����ĸ��

	pParam->i_threads = X264_SYNC_LOOKAHEAD_AUTO;
	pParam->i_keyint_max = 10;              //�ڴ˼������IDR�ؼ�֡

	///slice :live ֱ��
	pParam->i_slice_count = 4;

	pParam->rc.i_bitrate = 1200;       // ��������,��ABR(ƽ������)ģʽ�²���Ч���ұ���������ABRǰ������bitrate
	pParam->rc.i_rc_method = X264_RC_ABR;  // ���ʿ��Ʒ�����CQP(�㶨����)��CRF(�㶨����,ȱʡֵ23)��ABR(ƽ������)

										   /*
										   //Param
										   pParam->i_log_level  = X264_LOG_DEBUG;
										   pParam->i_frame_total = 0;
										   pParam->i_bframe  = 5;
										   pParam->b_open_gop  = 0;
										   pParam->i_bframe_pyramid = 0;
										   pParam->rc.i_qp_constant=0;
										   pParam->rc.i_qp_max=0;
										   pParam->rc.i_qp_min=0;
										   pParam->i_bframe_adaptive = X264_B_ADAPT_TRELLIS;
										   pParam->i_timebase_den = pParam->i_fps_num;
										   pParam->i_timebase_num = pParam->i_fps_den;
										   */

										   //set profile
	x264_param_apply_profile(pParam, "baseline");

	//open encoder
	pHandle = x264_encoder_open(pParam);

	x264_picture_init(pPic_out);//out.picture
	//I420,yuv420p
	x264_picture_alloc(pPic_in, csp, pParam->i_width, pParam->i_height);

	//ret = x264_encoder_headers(pHandle, &pNals, &iNal);

	y_size = pParam->i_width * pParam->i_height; //һ��ͼƬ��������
	//yuv��һ�����ص���ռ�����ֽ��أ���
	/// yuv444: 3, yuv422:2, yuv420:1.5
	//detect frame number
	if (frame_num == 0) {//���ԣ�������������֡��
		fseek(fp_src, 0, SEEK_END);//ָ�뵽�ļ�β��������
		switch (csp) {
		case X264_CSP_I444:frame_num = ftell(fp_src) / (y_size * 3);break;
		case X264_CSP_I422:frame_num = ftell(fp_src) / (y_size * 2);break;
		case X264_CSP_I420:frame_num = ftell(fp_src) / (y_size * 3 / 2);break;
		default:printf("Colorspace Not Support.\n");return -1;
		}
		fseek(fp_src, 0, SEEK_SET);
	}

	//Loop to Encode
	for (i = 0;i<frame_num;i++) {
		switch (csp) {
		case X264_CSP_I444: {
			fread(pPic_in->img.plane[0], y_size, 1, fp_src);         //Y
			fread(pPic_in->img.plane[1], y_size, 1, fp_src);         //U
			fread(pPic_in->img.plane[2], y_size, 1, fp_src);         //V
			break;}
		case X264_CSP_I422: {
			int index = 0;
			int y_i = 0, u_i = 0, v_i = 0;
			for (index = 0; index < y_size * 2;) {
				fread(&pPic_in->img.plane[0][y_i++], 1, 1, fp_src);   //Y
				index++;
				fread(&pPic_in->img.plane[1][u_i++], 1, 1, fp_src);   //U
				index++;
				fread(&pPic_in->img.plane[0][y_i++], 1, 1, fp_src);   //Y
				index++;
				fread(&pPic_in->img.plane[2][v_i++], 1, 1, fp_src);   //V
				index++;
			}break;}

		case X264_CSP_I420: {
			fread(pPic_in->img.plane[0], y_size, 1, fp_src);         //Y
			fread(pPic_in->img.plane[1], y_size / 4, 1, fp_src);       //U
			fread(pPic_in->img.plane[2], y_size / 4, 1, fp_src);       //V
			break;}
		default: {
			printf("Colorspace Not Support.\n");
			return -1;}
		}
		pPic_in->i_pts = i;

		ret = x264_encoder_encode(pHandle, &pNals, &iNal, pPic_in, pPic_out);
		if (ret< 0) {
			printf("Error.\n");
			return -1;
		}

		printf("Succeed encode frame: %5d\n", i);

		for (j = 0; j < iNal; ++j) {
			fwrite(pNals[j].p_payload, 1, pNals[j].i_payload, fp_dst);
		}
	}
	i = 0;
	//flush encoder
	while (1) {
		ret = x264_encoder_encode(pHandle, &pNals, &iNal, NULL, pPic_out);
		if (ret == 0) {
			break;
		}
		printf("Flush 1 frame.\n");
		for (j = 0; j < iNal; ++j) {
			fwrite(pNals[j].p_payload, 1, pNals[j].i_payload, fp_dst);
		}
		i++;
	}
	x264_picture_clean(pPic_in);
	x264_encoder_close(pHandle);
	pHandle = NULL;

	free(pPic_in);
	free(pPic_out);
	free(pParam);

	fclose(fp_src);
	fclose(fp_dst);

    return 0;

}

int _tmain23423(int argc, _TCHAR* argv[])
{
	return 0;
}

